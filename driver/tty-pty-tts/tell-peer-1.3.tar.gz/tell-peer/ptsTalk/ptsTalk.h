#ifndef _TALK_PTS_H
#define _TALK_PTS_H 1

#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <sys/un.h>


#define SUPPORT_STDIN 0

struct pts_id {
#define PTS_MAGIC	0xaab12cdd
	int pts_magic;
	int pts_dev_name;
	int pts_pid;
    int pts_fd;
    int sock_fd;
    pthread_mutex_t mutex;
};

typedef enum {
    PTS_ON,
    PTS_OFF,
}pts_stat;

enum pts_log {LOG_THIS_PTS, LOG_PEER_PTS};

struct pts_process {
    
    pthread_mutex_t mutex;

    char cmd[1024];
    int pipefd_out[2];

#if SUPPORT_STDIN    
    int pipefd_in[2];
#endif

    int pts_fd;
    
    FILE *istream;
    FILE *ostream;
    
    pthread_t pipe_read_task;
#if SUPPORT_STDIN
    pthread_t pipe_write_task;
#endif
    enum pts_log log_flag;
    
    struct pts_id *peer_pts;
};

typedef int (*pts_connect_fn)(struct pts_id*, pts_stat stat);

int pts_master(struct pts_id *master, pts_connect_fn fn);
int pts_slave(struct pts_id*);

int pts_vexe(struct pts_process *, char *cmd_str, ...);
int pts_bind_process(struct pts_id *, struct pts_process *);
int pts_reset_process(struct pts_process *);

int pts_print(struct pts_id *pts, char *fmt, ...);


#endif//_TALK_PTS_H