#include <stdio.h>

#include "ptsTalk.h"


struct pts_process process1,process2,process3;

int slaves_connect_callback(struct pts_id* slave_info, pts_stat stat)
{
    printf("Get a slave.\n");
    static int ipts = 0;

    switch(stat)
    {
        case PTS_ON:
            if(ipts==0)
            {
                pts_bind_process(slave_info, &process1);
            }
//            else if(ipts==1)
//            {
//                pts_bind_process(slave_info, &process2);
//            }
//            else if(ipts==2)
//            {
//                pts_bind_process(slave_info, &process3);
//            }
//            ipts++;
            break;

        case PTS_OFF:
            pts_reset_process(&process1);
            break;
    }   
    
    



    
    
    return 0;
}

int main()
{
    struct pts_id master;
    pts_master(&master, &slaves_connect_callback);

    int i =0 ;

    pts_vexe(&process1, "./test %d", i++);
//    pts_vexe(&process2, "./test %d", i++);
//    pts_vexe(&process3, "./test %d", i++);
    
    while(1)
    {
        printf("while1...\n");
        sleep(2);
    }
    return 0;
}
