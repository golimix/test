#ifndef _TALK_PTS_H
#define _TALK_PTS_H 1

#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <sys/un.h>


struct pts_id {
#define PTS_MAGIC	0xaab12cdd
	int pts_magic;
	int pts_dev_name;
	int pts_pid;
};

typedef enum {
    PTS_ON,
    PTS_OFF,
}pts_stat;

typedef int (*pts_connect_fn)(struct pts_id*, pts_stat stat);

int pts_master(pts_connect_fn fn);
int pts_slave(struct pts_id*);

int pts_print(struct pts_id *pts, char *fmt, ...);


#endif//_TALK_PTS_H