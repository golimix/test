#include <stdio.h>

#include "ptsTalk.h"

int slaves_connect_callback(struct pts_id* slave_info, pts_stat stat)
{
    printf("Get a slave.\n");
    
    int i;
    for(i=0;i<3;i++)
    {
        pts_print(slave_info, "Get a slave. %d\n", i);
        sleep(1);
    }
    
    return 0;
}



int main()
{
    pts_master(&slaves_connect_callback);

    
    while(1)
    {
        sleep(2);
    }
    return 0;
}
