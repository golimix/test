#include <stdio.h>

#include "ptsTalk.h"

int main()
{   
    struct pts_id master;
    
    pts_slave(&master);

    pts_print(&master, ">>>>>>>>>>>>>>>>>>>>>>>>>I got it.\n");
    
    while(1)
    {
        sleep(2);
    }
    return 0;
}
