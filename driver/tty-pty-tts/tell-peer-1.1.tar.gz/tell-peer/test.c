#include <stdio.h>
#include <signal.h>


void sig_handler(int signum)
{
    printf("TEST: get SIGINT signal.\n");
    exit(1);
}

int main()
{
    signal(SIGINT, sig_handler);
    while(1)
    {
        fprintf(stdout, "TEST: stdout.\n");
        fprintf(stderr, "TEST: stderr.\n");
        sleep(2);
    }
}
