#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <stdlib.h>


void sig_handler(int signum)
{
    printf("TEST: get SIGINT signal.\n");
    exit(1);
}

int main(int argc, char *argv[])
{
    signal(SIGINT, sig_handler);
    char buf[256];
    char subfix[32] = {0};
    
    if(argc > 1)
    {
        strncpy(subfix, argv[1], sizeof(subfix));
    }
    while(1)
    {
        
        fprintf(stderr, "TEST: fprintf stderr. %s\n", subfix);
        fflush(stderr);
        write(fileno(stderr), "TEST: write stderr.\n", sizeof("TEST: write stderr.\n"));
        fflush(stderr);
        
        sleep(1);
        
        fprintf(stdout, "TEST: fprintf stdout. %s\n", subfix);
        fflush(stdout);
        write(fileno(stdout), "TEST: write stdout.\n", sizeof("TEST: write stdout.\n"));
        fflush(stdout);
        
        sleep(1);

//        fscanf(stdin, "%s", buf);
//        
//        fprintf(stdout, "buf: %s\n", buf);
//        write(fileno(stdout), "buf: %s\n", buf);
        
    }
}
